Oil Manager V1.2 CLEAN
Package: com.ramadanalkharaz.oils
Android WebView app for Ramadan Al Kharaz Center.
Clean build: AGP 8.6.1, Gradle 8.7, Java 17, no AndroidX dependencies.
