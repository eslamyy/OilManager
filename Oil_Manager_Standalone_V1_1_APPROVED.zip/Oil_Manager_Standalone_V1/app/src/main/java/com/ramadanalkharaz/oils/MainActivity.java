package com.ramadanalkharaz.oils;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.os.CancellationSignal;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import android.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 8001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setDefaultTextEncodingName("UTF-8");
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null); filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json");
                try { startActivityForResult(i, FILE_CHOOSER_REQUEST); return true; } catch(Exception e){ filePathCallback=null; return false; }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==FILE_CHOOSER_REQUEST && filePathCallback!=null){ Uri[] r=null; if(resultCode==RESULT_OK && data!=null && data.getData()!=null) r=new Uri[]{data.getData()}; filePathCallback.onReceiveValue(r); filePathCallback=null; }
    }

    public class Bridge {
        @JavascriptInterface public void saveBackup(String filename, String content) {
            try {
                ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME, filename); v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q) v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); OutputStream out=getContentResolver().openOutputStream(uri); out.write(content.getBytes(StandardCharsets.UTF_8)); out.close();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"تم حفظ النسخة الاحتياطية في Download",Toast.LENGTH_LONG).show());
            } catch(Exception e){ runOnUiThread(() -> Toast.makeText(MainActivity.this,"تعذر حفظ النسخة",Toast.LENGTH_LONG).show()); }
        }
        @JavascriptInterface public void shareText(String text) {
            try { Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text); startActivity(Intent.createChooser(i,"مشاركة")); }
            catch(Exception e){ runOnUiThread(() -> Toast.makeText(MainActivity.this,"تعذر فتح المشاركة",Toast.LENGTH_SHORT).show()); }
        }
        @JavascriptInterface public void createPdfAndShare(String filename, String html) {
            runOnUiThread(() -> createPdf(filename, html));
        }
    }

    private void createPdf(String filename, String html) {
        final WebView pdfWeb = new WebView(this);
        WebSettings s = pdfWeb.getSettings(); s.setJavaScriptEnabled(false); s.setDefaultTextEncodingName("UTF-8");
        pdfWeb.setWebViewClient(new WebViewClient(){
            @Override public void onPageFinished(WebView view, String url){
                try {
                    File dir = new File(getCacheDir(), "pdf"); if(!dir.exists()) dir.mkdirs();
                    File outFile = new File(dir, filename.replaceAll("[^a-zA-Z0-9._-]", "_"));
                    PrintDocumentAdapter adapter = pdfWeb.createPrintDocumentAdapter("OilManager");
                    PrintAttributes attrs = new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf","pdf",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                    adapter.onLayout(null, attrs, new CancellationSignal(), new PrintDocumentAdapter.LayoutResultCallback(){
                        @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed){
                            try {
                                ParcelFileDescriptor pfd = ParcelFileDescriptor.open(outFile, ParcelFileDescriptor.MODE_CREATE | ParcelFileDescriptor.MODE_TRUNCATE | ParcelFileDescriptor.MODE_READ_WRITE);
                                adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, pfd, new CancellationSignal(), new PrintDocumentAdapter.WriteResultCallback(){
                                    @Override public void onWriteFinished(PageRange[] pages){ try{pfd.close();}catch(Exception ignored){} sharePdf(outFile); pdfWeb.destroy(); }
                                    @Override public void onWriteFailed(CharSequence error){ try{pfd.close();}catch(Exception ignored){} Toast.makeText(MainActivity.this,"تعذر إنشاء PDF",Toast.LENGTH_SHORT).show(); pdfWeb.destroy(); }
                                });
                            } catch(Exception e){ Toast.makeText(MainActivity.this,"تعذر إنشاء PDF",Toast.LENGTH_SHORT).show(); pdfWeb.destroy(); }
                        }
                        @Override public void onLayoutFailed(CharSequence error){ Toast.makeText(MainActivity.this,"تعذر تجهيز PDF",Toast.LENGTH_SHORT).show(); pdfWeb.destroy(); }
                    }, null);
                } catch(Exception e){ Toast.makeText(MainActivity.this,"تعذر إنشاء PDF",Toast.LENGTH_SHORT).show(); pdfWeb.destroy(); }
            }
        });
        String encoded = Base64.encodeToString(html.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        pdfWeb.loadDataWithBaseURL(null, encoded, "text/html", "base64", null);
    }

    private void sharePdf(File file){
        try{
            Uri uri = FileProvider.getUriForFile(this, getPackageName()+".fileprovider", file);
            Intent i = new Intent(Intent.ACTION_SEND); i.setType("application/pdf"); i.putExtra(Intent.EXTRA_STREAM, uri); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(i,"مشاركة ملف PDF"));
        }catch(Exception e){ Toast.makeText(this,"تم إنشاء PDF ولكن تعذرت المشاركة",Toast.LENGTH_LONG).show(); }
    }
}
