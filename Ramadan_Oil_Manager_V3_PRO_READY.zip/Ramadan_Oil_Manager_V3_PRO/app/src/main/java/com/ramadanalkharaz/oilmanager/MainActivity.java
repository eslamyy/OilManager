package com.ramadanalkharaz.oilmanager;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(this), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    class AndroidBridge {
        private final Context context;
        AndroidBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void printHtml(String html, String jobName) {
            runOnUiThread(() -> {
                WebView printView = new WebView(context);
                printView.getSettings().setJavaScriptEnabled(true);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        pm.print(jobName, view.createPrintDocumentAdapter(jobName), new PrintAttributes.Builder().build());
                    }
                });
                printView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            });
        }

        @JavascriptInterface
        public void sharePdf(String title, String body) {
            new Thread(() -> {
                try {
                    Uri uri = createPdf(title, body);
                    runOnUiThread(() -> {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("application/pdf");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        Intent chooser = Intent.createChooser(send, "إرسال الإيصال / الفاتورة");
                        startActivity(chooser);
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(context, "تعذر إنشاء PDF: " + e.getMessage(), Toast.LENGTH_LONG).show());
                }
            }).start();
        }

        private Uri createPdf(String title, String body) throws Exception {
            PdfDocument doc = new PdfDocument();
            int width = 595, height = 842;
            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(width, height, 1).create();
            PdfDocument.Page page = doc.startPage(pageInfo);
            Canvas canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);

            Paint header = new Paint(Paint.ANTI_ALIAS_FLAG);
            header.setColor(Color.rgb(123, 7, 39));
            canvas.drawRect(0, 0, width, 118, header);

            Bitmap logo = BitmapFactory.decodeResource(getResources(), com.ramadanalkharaz.oilmanager.R.drawable.center_logo);
            if (logo != null) {
                float ratio = Math.min(92f / logo.getWidth(), 92f / logo.getHeight());
                int w = Math.round(logo.getWidth() * ratio);
                int h = Math.round(logo.getHeight() * ratio);
                Bitmap scaled = Bitmap.createScaledBitmap(logo, w, h, true);
                canvas.drawBitmap(scaled, (width - w) / 2f, 8, null);
            }

            TextPaint titlePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            titlePaint.setColor(Color.rgb(123,7,39));
            titlePaint.setTextSize(22);
            titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            StaticLayout titleLayout = StaticLayout.Builder.obtain(title, 0, title.length(), titlePaint, width - 64)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false).build();
            canvas.save(); canvas.translate(32, 138); titleLayout.draw(canvas); canvas.restore();

            TextPaint bodyPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
            bodyPaint.setColor(Color.rgb(35,35,35));
            bodyPaint.setTextSize(15);
            bodyPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
            StaticLayout bodyLayout = StaticLayout.Builder.obtain(body, 0, body.length(), bodyPaint, width - 70)
                    .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
                    .setLineSpacing(4f, 1.0f)
                    .setIncludePad(false).build();
            canvas.save(); canvas.translate(35, 190); bodyLayout.draw(canvas); canvas.restore();

            doc.finishPage(page);

            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            String safe = title.replaceAll("[^\\p{L}\\p{N}]+", "_");
            values.put(MediaStore.Downloads.DISPLAY_NAME, safe + "_" + System.currentTimeMillis() + ".pdf");
            values.put(MediaStore.Downloads.MIME_TYPE, "application/pdf");
            values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/RamadanOilManager");
            Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("تعذر إنشاء الملف");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                doc.writeTo(out);
            }
            doc.close();
            return uri;
        }
    }
}
