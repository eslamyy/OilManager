Oil Manager V1.0
Standalone Android WebView app for Ramadan Al Kharaz Center.
Package: com.ramadanalkharaz.oils
Features: oil service operations, separate oil inventory, automatic stock deduction, history, reports, backup/restore.
