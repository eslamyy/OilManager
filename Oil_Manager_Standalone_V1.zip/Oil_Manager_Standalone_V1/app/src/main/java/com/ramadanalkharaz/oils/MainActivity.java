package com.ramadanalkharaz.oils;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.Build;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 8001;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setDefaultTextEncodingName("UTF-8");
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                try { startActivityForResult(i, FILE_CHOOSER_REQUEST); return true; }
                catch(Exception e){ filePathCallback=null; return false; }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==FILE_CHOOSER_REQUEST && filePathCallback!=null){
            Uri[] r=null;
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null) r=new Uri[]{data.getData()};
            filePathCallback.onReceiveValue(r); filePathCallback=null;
        }
    }

    public class Bridge {
        @JavascriptInterface public void saveBackup(String filename, String content) {
            try {
                ContentValues v=new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                v.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q) v.put(MediaStore.Downloads.RELATIVE_PATH,"Download");
                Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                OutputStream out=getContentResolver().openOutputStream(uri);
                out.write(content.getBytes(StandardCharsets.UTF_8)); out.close();
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"تم حفظ النسخة الاحتياطية في Download",Toast.LENGTH_LONG).show());
            } catch(Exception e){ runOnUiThread(() -> Toast.makeText(MainActivity.this,"تعذر حفظ النسخة",Toast.LENGTH_LONG).show()); }
        }
        @JavascriptInterface public void shareText(String text) {
            try { Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text); startActivity(Intent.createChooser(i,"مشاركة")); }
            catch(Exception e){ runOnUiThread(() -> Toast.makeText(MainActivity.this,"تعذر فتح المشاركة",Toast.LENGTH_SHORT).show()); }
        }
    }
}
