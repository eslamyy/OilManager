Oil Manager FRESH V1
Package: com.ramadanalkharaz.oils
Pure Android WebView + HTML/JS. No AndroidX dependencies.
Java 17 / compileSdk 35 / targetSdk 35 / minSdk 24.
